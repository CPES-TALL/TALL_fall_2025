"""
CPES DAC 2025-2026
TAL²
Mathieu Dehouck
"""

"""
Ceci est un TP noté. 
J'aimerais bien que vous n'utilisiez pas d'agent conversationnel.

Ecrivez vos réponses et vos remarques dans un document que vous sauvegarderez en PDF et remettrez sur Moodle.
Les questions sont indiquées par le symbol %
"""

"""
Dans ce TP, nous allons sonder les représentations contextuelles des LLM.
Les LLM apprennent d'une grande quantité de donnée et donc il n'est pas surprenant qu'ils acquièrent des propriétés émergentes.
Le sondage ou probing est un moyen d'estimer ces propriétés.
"""

from random import randint, seed
from os import scandir
import torch
from torch import Tensor, nn
from tqdm import tqdm, trange
import numpy as np

# loading a transformer model and the tokenizer that comes with it
from transformers import AutoTokenizer, AutoModelForMaskedLM

# aujourd'hui on utilisera seulement bert
model_name = "google-bert/bert-base-uncased"
tokenizer = AutoTokenizer.from_pretrained(model_name)
model = AutoModelForMaskedLM.from_pretrained(model_name, output_hidden_states=True)


# set the seeds to be as reproducible as possible
seed(0)
torch.manual_seed(0)


# reading some data
fname = 'en_ewt-ud-train.conllu'
data = [[]]

for l in open(fname): # take care of your encoding
    l = l.strip()
    if l == '':
        continue
    
    if l[0] == '#':
        if data[-1] != []:
            data.append([])
        continue

    l = l.split('\t')
    if '-' in l[0] or '.' in l[0]:
        continue

    data[-1].append(l)

print(len(data))

# mini trains et test
# vous allez comprendre pourquoi
train = data[:100]
trains = [data[i:i+100] for i in range(0,300,100)]
test = data[1000:3000]


# conllu to str to tokens to representation
sen = train[0]
txt = ' '.join(w[1] for w in sen)
toks_ids = tokenizer(txt, add_special_tokens=False)

embs = model(Tensor([toks_ids['input_ids']]).long()) # given a tensor of indices, the transformer return a series of representations most importantly, embs[0] and embs[1]
# 1 % what are the sizes/dimensions of embs[0] and embs[1], what do you infer from it ?


##
## PROBING
##

# once you understand the tokenizer, you need to find a way to match POS tags to the tokenized sentences since a word can correspond to several vectors in the final representation
# you will align the first token of each word with its POS (w[3]) in each sentence
# you need to get the number of POS and turn the POS into indices,
# then, the tokens that do not correspond to a POS can be tagged -100 (it tells the models to ignore them at training time)
# then initialise a simple one layer perceptron to predict the POS of a word given the representation of its first token. You need to know the dimension of a word embedding!

#linear = mlp(dim, nclass)      # a model # you should have mlp in a previous TP
floss = nn.CrossEntropyLoss()   # a loss function 
trainer = torch.optim.Adam(linear.parameters())    # an optimizer

# train you perceptron for 100 sentences on a single epoch to predict POS tags,
# the goal here is not to have a great model but to see how easily the information is available in different representations.
# Compute the accuracy of you model on the test set each time.
# 2 % repeat the process for each representation layer for each small train in trains (3 sets), report all of that in a table with average per layer
# 3 % analyse the results in terms of representation depth.


    
# if you arrived here, congratulation.
# 4 % train the same mlp with its own torch.nn.embedding module in order to see how it would do without the LLM

