"""
CPES DAC 2025-2026
TAL²
Mathieu Dehouck
"""

"""
Ceci est un TP noté. 
J'aimerais bien que vous n'utilisiez pas d'agent conversationnel.

Ecrivez vos réponses et vos remarques dans un document que vous sauvegarderez en PDF et remettrez sur Moodle.
Les questions sont indiquées par le symbol %
"""

"""
Dans ce TP, nous allons sonder les représentations contextuelles des LLM.
Les LLM apprennent d'une grande quantité de donnée et donc il n'est pas surprenant qu'ils acquièrent des propriétés émergentes.
Le sondage ou probing est un moyen d'estimer ces propriétés.
"""

from random import randint, seed, random
from os import scandir
import torch
from torch import Tensor, nn
from tqdm import tqdm, trange
import numpy as np
from collections import defaultdict
#from plotly import express as ex
from math import log

# loading a transformer model and the tokenizer that comes with it
from transformers import AutoTokenizer, AutoModelForMaskedLM

model_name = "google-bert/bert-base-uncased"
model_name_2 = "camembert/camembert-base-wikipedia-4gb"
tokenizer = AutoTokenizer.from_pretrained(model_name)


# set the seeds to be as reproducible as possible
seed(0)
torch.manual_seed(0)


# reading some data, this is a conllu, so the form is in the second column
fname = 'en_ewt-ud-train.conllu'
data = [[]]

for l in open(fname): # take care of your encoding
    l = l.strip()
    if l == '':
        continue
    
    if l[0] == '#':
        if data[-1] != []:
            data.append([])
        continue

    l = l.split('\t')
    if '-' in l[0] or '.' in l[0]:
        continue

    data[-1].append(l)

print(len(data))

# mini train
train = data[:100]
trains = [data[i:i+100] for i in range(0,300,100)]
test = data[1000:3000]

# un point important pour le travail avec les LLM est la tokenisation, qui a ici un sens un peu différent que celui que nous avons vu en cours.
# un token est une unité minimale du vocabulaire du LLM, c'est un chaine de caractère qui a une représentation, un mot rare peut être découper en plusieurs tokens.

tr_sen = []
# try to understand how the tokisation works (roughly)
# 1 % what is the average number of token per word in the small train, and in the test ?
# 2 % give examples of words from data that are tokenized in 1, 2, 3 and more if you find, with their tokenisations.
# 3 % do the same for french data in the same folder and see what's happening, what's your analysis ?
# 4 % now load the french camembert tokenizer and repeat 1 %, 2 % and 3 %, what does it tell you ?

toks_ids = tokenizer(txt, add_special_tokens=False) # get the tokens ids and extra bits from a string
toks = tokenizer.convert_ids_to_tokens(toks_ids['input_ids']) # get the forms from the ids



# revert to the english tokenizer
    
# get frequency of about 4000 words from project gutenberg from Wiktionary
vocabulary = [l.strip().split() for l in open('freq_en')] # each line has the format :   rank  form  frequency
# 5 % use these data to analyse and discuss the relation between word length, word frequency and number of tokens used to represent it
                         

# now load the actual model
model = AutoModelForMaskedLM.from_pretrained(model_name, output_hidden_states=True)

sen = train[0] # take a sentence
txt = ' '.join(w[1] for w in sen) # make it a string
toks_ids = tokenizer(txt, add_special_tokens=False) # tokenize

embs = model(Tensor([toks_ids['input_ids']]).long()) # given a tensor of indices, the transformer return a series of representations most importantly, embs[0] and embs[1]
# 6 % what are the sizes/dimensions of embs[0] and embs[1], what do you infer from it ?

